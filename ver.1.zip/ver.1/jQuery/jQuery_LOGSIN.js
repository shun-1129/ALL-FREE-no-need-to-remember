$(function(){
	$('#LOGIN_BUTTON').on('click', function(){
		$('#LOG_SIN').css('display', 'none');
		$('#LOGIN_FORM').css('display', 'block');
		
		return false;
	});
});
