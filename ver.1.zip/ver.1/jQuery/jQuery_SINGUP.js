$(function(){
	$('#SINGUP_BUTTON').on('click', function(){
		$('#LOG_SIN').css('display', 'none');
		$('#SINGUP_FROM').css('display', 'block');
		
		return false;
	});
});