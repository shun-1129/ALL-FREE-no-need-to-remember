$(function(){
	$('.MAIN_RETURN').on('click', function(){
		$('#LOGIN_FORM').css('display', 'none');
		$('#SINGUP_FROM').css('display', 'none');
		$('#LOG_SIN').css('display', 'block');
	});
});